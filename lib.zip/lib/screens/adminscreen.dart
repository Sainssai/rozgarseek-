import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:razgorsek/screens/authentication.dart';

class AdminHome extends StatefulWidget {
  @override
  _AdminHomeState createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  int _selectedIndex = 0;
  final String keyId = 'rzp_test_52dp1Z8qV4bxDM';
  final String keySecret = '5fbghfhOvpq1gur8mgQS1Sbk';
  final String authString = 'rzp_test_1UycNEI9tDTlug:wm751JVrlwhSSBOMRxrKWWQO';
  late final String basicAuth;

  @override
  void initState() {
    super.initState();
    basicAuth = 'Basic ${base64.encode(utf8.encode(authString))}';
    print('Authorization header: $basicAuth'); // Debug auth
  }

  Future<void> _initiateRazorpayRefund(String transactionId, int amount) async {
    try {
      print(
        'Initiating refund for transactionId: $transactionId, amount: $amount paise',
      );
      final response = await http.post(
        Uri.parse('https://api.razorpay.com/v1/payments/$transactionId/refund'),
        headers: {
          'Authorization': basicAuth,
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'amount': amount,
          'speed': 'normal',
          'notes': {'reason': 'User requested refund'},
        }),
      );

      print(
        'Razorpay refund response: ${response.statusCode} ${response.body}',
      );

      if (response.statusCode == 200) {
        Get.snackbar('Success', 'Refund processed successfully.');
      } else {
        final errorData = json.decode(response.body);
        print('Error details: ${errorData['error'] ?? 'No error details'}');
        Get.snackbar('Error', 'Refund failed: ${response.body}');
      }
    } catch (e) {
      print('Refund error: $e');
      Get.snackbar('Error', 'Refund initiation failed: $e');
      try {
        final testResponse = await http.get(
          Uri.parse('https://api.razorpay.com/v1/ping'),
        );
        print(
          'Razorpay ping response: ${testResponse.statusCode} ${testResponse.body}',
        );
      } catch (pingError) {
        print('Ping error: $pingError');
      }
    }
  }

  Future<void> _changeProviderStatus(String providerId) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(providerId)
          .update({'isBooked': false});
      Get.snackbar('Success', 'Provider status updated to available.');
    } catch (e) {
      print('Provider status update error: $e');
      Get.snackbar('Error', 'Failed to update provider status: $e');
    }
  }

  Widget _buildRefundsTab() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Text(
            'Refunds',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('refundrequests')
                  .where('status', isEqualTo: 'pending')
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData)
                  return Center(child: CircularProgressIndicator());
                final refunds = snapshot.data!.docs;
                return ListView.builder(
                  itemCount: refunds.length,
                  itemBuilder: (context, index) {
                    final refund = refunds[index];
                    return FutureBuilder<DocumentSnapshot>(
                      future: FirebaseFirestore.instance
                          .collection('users')
                          .doc(refund['userId'])
                          .get(),
                      builder: (context, userSnapshot) {
                        if (!userSnapshot.hasData) return Container();
                        var userData =
                            userSnapshot.data!.data() as Map<String, dynamic>;
                        final amountInPaise = (refund['price'] * 100).toInt();
                        return ListTile(
                          title: Text('Service: ${refund['service']}'),
                          subtitle: Text(
                            'User: ${userData['email']} '
                            'Price: ₹${refund['price']} '
                            'Transaction ID: ${refund['transactionId']} '
                            'Requested: ${refund['timestamp']?.toDate().toLocal().toString().split(' ')[0] ?? 'N/A'}',
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(Icons.check, color: Colors.green),
                                onPressed: () async {
                                  try {
                                    await _initiateRazorpayRefund(
                                      refund['transactionId'],
                                      amountInPaise,
                                    );
                                    await FirebaseFirestore.instance
                                        .collection('refundrequests')
                                        .doc(refund.id)
                                        .update({'status': 'approved'});
                                    await FirebaseFirestore.instance
                                        .collection('bookings')
                                        .doc(refund['bookingId'])
                                        .update({'status': 'refunded'});
                                    Get.snackbar(
                                      'Success',
                                      'Refund approved and processed.',
                                    );
                                  } catch (e) {
                                    Get.snackbar(
                                      'Error',
                                      'Refund processing failed.',
                                    );
                                  }
                                },
                              ),
                              IconButton(
                                icon: Icon(Icons.close, color: Colors.red),
                                onPressed: () async {
                                  await FirebaseFirestore.instance
                                      .collection('refundrequests')
                                      .doc(refund.id)
                                      .update({'status': 'rejected'});
                                  Get.snackbar('Success', 'Refund rejected.');
                                },
                              ),
                              ElevatedButton(
                                onPressed: () async {
                                  await _changeProviderStatus(
                                    refund['providerId'],
                                  );
                                },
                                child: Text('Update Status'),
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatsTab() {
    return Center(
      child: Text(
        'Chats (To be implemented later)',
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildSearchTab() {
    String userQuery = '';
    String providerQuery = '';
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Text(
            'Search',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          TextField(
            decoration: InputDecoration(
              labelText: 'Search Users with Booked Services',
              border: OutlineInputBorder(),
            ),
            onChanged: (value) {
              setState(() {
                userQuery = value;
              });
            },
          ),
          SizedBox(height: 10),
          TextField(
            decoration: InputDecoration(
              labelText: 'Search Active Booked Providers',
              border: OutlineInputBorder(),
            ),
            onChanged: (value) {
              setState(() {
                providerQuery = value;
              });
            },
          ),
          SizedBox(height: 20),
          Expanded(
            child: Column(
              children: [
                Text('Users with Booked Services'),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('bookings')
                        .where('status', isEqualTo: 'success')
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData)
                        return Center(child: CircularProgressIndicator());
                      final bookings = snapshot.data!.docs.where((doc) {
                        final userId = doc['userId'];
                        return userId.contains(userQuery);
                      }).toList();
                      return ListView.builder(
                        itemCount: bookings.length,
                        itemBuilder: (context, index) {
                          final booking = bookings[index];
                          return FutureBuilder<DocumentSnapshot>(
                            future: FirebaseFirestore.instance
                                .collection('users')
                                .doc(booking['userId'])
                                .get(),
                            builder: (context, userSnapshot) {
                              if (!userSnapshot.hasData) return Container();
                              var userData =
                                  userSnapshot.data!.data()
                                      as Map<String, dynamic>;
                              return ListTile(
                                title: Text('User: ${userData['email']}'),
                                subtitle: Text(
                                  'Service: ${booking['service']} | Price: ₹${booking['price']}',
                                ),
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ),
                Text('Active Booked Providers'),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('users')
                        .where('role', isEqualTo: 'provider')
                        .where('isBooked', isEqualTo: true)
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData)
                        return Center(child: CircularProgressIndicator());
                      final providers = snapshot.data!.docs.where((doc) {
                        final email = doc['email'] ?? '';
                        return email.contains(providerQuery);
                      }).toList();
                      return ListView.builder(
                        itemCount: providers.length,
                        itemBuilder: (context, index) {
                          final provider = providers[index];
                          return ListTile(
                            title: Text('Provider: ${provider['email']}'),
                            subtitle: Text(
                              'Category: ${provider['category']} | Location: ${provider['location']}',
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogoutTab() {
    return Center(
      child: ElevatedButton(
        onPressed: () async {
          await FirebaseAuth.instance.signOut();
          Get.offAll(() => AuthScreen());
        },
        child: Text('Logout'),
      ),
    );
  }

  List<Widget> get _pages => [
    _buildRefundsTab(),
    _buildChatsTab(),
    _buildSearchTab(),
    _buildLogoutTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Admin Panel')),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.money), label: 'Refunds'),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chats'),
          BottomNavigationBarItem(icon: Icon(Icons.search), label: 'Search'),
          BottomNavigationBarItem(icon: Icon(Icons.logout), label: 'Logout'),
        ],
      ),
    );
  }
}
