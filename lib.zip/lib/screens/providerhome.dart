
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:razgorsek/screens/authentication.dart';
import 'package:razgorsek/screens/providerchart.dart';

class ProviderHomePage extends StatelessWidget {
  const ProviderHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Provider Home"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            tooltip: 'Log Out',
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Get.offAll(() => AuthScreen());
            },
          ),
        ],
      ),
      body: ElevatedButton(
        child: Text("View Chats"),
        onPressed: () => Get.to(() => ProviderChatList()),
      ),
    );
  }
}

