
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:razgorsek/screens/chatscreen.dart';

class ProviderChatList extends StatelessWidget {
  final currentUser = FirebaseAuth.instance.currentUser;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('User Chats')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('chats')
            .where('participants', arrayContains: currentUser!.email)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          }

          final chats = snapshot.data!.docs;
          final userList = chats.map((doc) {
            final participants = doc['participants'] as List<dynamic>;
            return participants.firstWhere((email) => email != currentUser!.email);
          }).toSet().toList();

          return ListView.builder(
            itemCount: userList.length,
            itemBuilder: (context, index) {
              final userEmail = userList[index];
              return ListTile(
                title: Text(userEmail),
                trailing: Icon(Icons.chat),
                onTap: () {
                  Get.to(() => ChatScreen(
                        peerEmail: userEmail,
                        peerName: "User",
                      ));
                },
              );
            },
          );
        },
      ),
    );
  }
}