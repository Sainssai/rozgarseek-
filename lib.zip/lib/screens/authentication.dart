// Your imports remain unchanged
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:razgorsek/screens/adminscreen.dart';
import 'package:razgorsek/screens/providerhome.dart';
import 'package:razgorsek/screens/userhome.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final _loginEmail = TextEditingController();
  final _loginPassword = TextEditingController();

  final _signupName = TextEditingController();
  final _signupEmail = TextEditingController();
  final _signupPassword = TextEditingController();
  final _signupPhone = TextEditingController();
  final _categoryController = TextEditingController();
  String _role = 'user';
  final _location = TextEditingController();

  bool showAdmin = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _checkIfAdminExists();
  }

  Future<void> _checkIfAdminExists() async {
    final adminQuery = await FirebaseFirestore.instance
        .collection('users')
        .where('role', isEqualTo: 'admin')
        .limit(1)
        .get();

    if (adminQuery.docs.isNotEmpty) {
      setState(() => showAdmin = false);
    }
  }

  Future<void> loginUser(String email, String password) async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: password);

      final uid = userCredential.user?.uid;
      if (uid == null) throw Exception("User UID is null");

      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(uid)
          .get();

      if (userDoc.exists) {
        final data = userDoc.data() as Map<String, dynamic>;
        final role = data['role'];
        final name = data['name'];

        if (role == 'admin') {
          Get.offAll(() =>  AdminHome());
        } else if (role == 'provider') {
          Get.offAll(() => const ProviderHomePage());
        } else {
          Get.offAll(() => UserHomePage(userName: name));
        }
      } else {
        throw Exception("User data not found in Firestore");
      }
    } catch (e) {
      Get.snackbar("Login Failed", e.toString());
    }

    _loginEmail.clear();
    _loginPassword.clear();
  }

  Future<void> signUp() async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
            email: _signupEmail.text.trim(),
            password: _signupPassword.text.trim(),
          );

      final userData = {
        'name': _signupName.text.trim(),
        'email': _signupEmail.text.trim(),
        'phone': _signupPhone.text.trim(),
        'role': _role,
      };
      if (_role != 'admin') {
        userData['location'] = _location.text.trim();
      }
      if (_role == 'provider') {
        userData['category'] = _categoryController.text.trim();
      }

      await FirebaseFirestore.instance
          .collection('users')
          .doc(userCredential.user!.uid)
          .set(userData);

      setState(() => _role = 'user');
      _tabController.animateTo(0);
      _checkIfAdminExists();

      Get.snackbar(
        "Success",
        "Account created. Please login.",
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } on FirebaseAuthException catch (e) {
      Get.snackbar(
        "Error",
        e.message ?? "Signup failed",
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar(
        "Error",
        e.toString(),
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }

    _signupName.clear();
    _signupEmail.clear();
    _signupPassword.clear();
    _signupPhone.clear();
    _location.clear();
    _categoryController.clear();
  }

  final _loginFormKey = GlobalKey<FormState>();
  final _signupFormKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/images/bg.jpg"),
                fit: BoxFit.fill,
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.6)),
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.8,
                constraints: const BoxConstraints(maxWidth: 400),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.95),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(blurRadius: 20, color: Colors.black26)],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset("assets/images/logo.jpg", height: 60),
                    const SizedBox(height: 10),
                    TabBar(
                      controller: _tabController,
                      indicatorColor: Colors.deepPurple,
                      labelColor: Colors.deepPurple,
                      unselectedLabelColor: Colors.grey,
                      tabs: const [
                        Tab(icon: Icon(Icons.login), text: "Login"),
                        Tab(icon: Icon(Icons.app_registration), text: "Signup"),
                      ],
                    ),
                    const SizedBox(height: 10),
                    // ✅ FIXED AREA
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.6,
                      child: TabBarView(
                        controller: _tabController,
                        children: [
                          SingleChildScrollView(child: _buildLoginForm()),
                          SingleChildScrollView(child: _buildSignupForm()),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoginForm() {
    return Form(
      key: _loginFormKey,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextFormField(
              controller: _loginEmail,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                labelText: "Email",
                prefixIcon: const Icon(Icons.email),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) return 'Email is required';
                if (!GetUtils.isEmail(value.trim())) return 'Enter valid email';
                return null;
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _loginPassword,
              obscureText: true,
              keyboardType: TextInputType.visiblePassword,
              decoration: InputDecoration(
                labelText: "Password",
                prefixIcon: const Icon(Icons.lock),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) return 'Password required';
                if (value.length < 6) return 'At least 6 characters';
                return null;
              },
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: () {
                if (_loginFormKey.currentState!.validate()) {
                  FocusScope.of(context).unfocus();
                  loginUser(
                    _loginEmail.text.trim(),
                    _loginPassword.text.trim(),
                  );
                }
              },
              icon: const Icon(Icons.login),
              label: const Text("Login"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSignupForm() {
    return Form(
      key: _signupFormKey,
      child: Column(
        children: [
          TextFormField(
            controller: _signupName,
            keyboardType: TextInputType.name,
            decoration: _inputDecoration("Name", Icons.person),
            validator: (value) =>
                value == null || value.isEmpty ? 'Name is required' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _signupEmail,
            keyboardType: TextInputType.emailAddress,
            decoration: _inputDecoration("Email", Icons.email),
            validator: (value) {
              if (value == null || value.isEmpty) return 'Email is required';
              if (!GetUtils.isEmail(value.trim())) return 'Enter valid email';
              return null;
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _signupPhone,
            keyboardType: TextInputType.phone,
            decoration: _inputDecoration("Phone", Icons.phone),
            validator: (value) =>
                value == null || value.isEmpty ? 'Phone is required' : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _signupPassword,
            obscureText: true,
            keyboardType: TextInputType.visiblePassword,
            decoration: _inputDecoration("Password", Icons.lock),
            validator: (value) => value == null || value.length < 6
                ? 'Password must be at least 6 characters'
                : null,
          ),
          const SizedBox(height: 12),
          if (_role != 'admin')
            TextFormField(
              controller: _location,
              decoration: _inputDecoration("Location", Icons.location_city),
              validator: (value) =>
                  value == null || value.isEmpty ? 'Location required' : null,
            ),
          if (_role != 'admin') const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _role,
            isExpanded: true,
            decoration: _inputDecoration("Role", Icons.account_circle),
            onChanged: (val) => setState(() => _role = val!),
            items: [
              const DropdownMenuItem(value: 'user', child: Text("USER")),
              const DropdownMenuItem(
                value: 'provider',
                child: Text("PROVIDER"),
              ),
              if (showAdmin)
                const DropdownMenuItem(value: 'admin', child: Text("ADMIN")),
            ],
            validator: (value) =>
                value == null || value.isEmpty ? 'Role is required' : null,
          ),
          if (_role == 'provider') ...[
            const SizedBox(height: 12),
            TextFormField(
              controller: _categoryController,
              decoration: _inputDecoration("Category", Icons.category),
              validator: (value) =>
                  value == null || value.isEmpty ? 'Category required' : null,
            ),
          ],
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: () {
              if (_signupFormKey.currentState!.validate()) {
                FocusScope.of(context).unfocus();
                signUp();
              }
            },
            icon: const Icon(Icons.app_registration),
            label: const Text("Signup"),
          ),
        ],
      ),
    );
  }

  InputDecoration _inputDecoration(String label, IconData icon) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
    );
  }
}
